// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getFirestore } from '@firebase/firestore';
const firebaseConfig = {
    apiKey: 'AIzaSyD95Nnwysykl92r5UTPkFcUTXIX1mdlulI',
    authDomain: 'blast-aa1c7.firebaseapp.com',
    projectId: 'blast-aa1c7',
    storageBucket: 'blast-aa1c7.appspot.com',
    messagingSenderId: '169625862421',
    appId: '1:169625862421:web:0717cd2e571b1b1ed9e91c',
    measurementId: 'G-ZZ0E7WVF2G'
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
