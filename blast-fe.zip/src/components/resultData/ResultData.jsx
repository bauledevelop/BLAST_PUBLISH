import React from 'react';
import PropTypes from 'prop-types';
import './ResultData.scss';

function resultData(props) {
    const { boxResultRef } = props;
    return (
        <>
            <div className="box-result">
                <div className="format-text-generate" ref={boxResultRef}>
                    <div className="generate-result" id="generateChat"></div>
                </div>
            </div>
        </>
    );
}

export default resultData;
