import PropTypes from 'prop-types';
import { Checkbox, FormControlLabel, Skeleton } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { Box } from '@mui/system';
import './TableOptions.scss';
import { clearOptions, resultOptionsFeedback } from 'services/FeedbackService';
import React from 'react';
import { useEffect, useState } from 'react';
TableOptions.propTypes = {
    band: PropTypes.array,
    TA: PropTypes.array,
    CAC: PropTypes.array,
    LR: PropTypes.array,
    GRAA: PropTypes.array,
    onSubmit: PropTypes.func,
    disable: PropTypes.bool
};
TableOptions.defaultProps = {
    band: [],
    TA: [],
    CAC: [],
    LR: [],
    GRAA: [],
    onSubmit: null
};

function TableOptions(props) {
    // const [cb, setCb] = useState(true);
    // const [checkboxState, setCheckboxState] = useState({});
    const { band, TA, CAC, LR, GRAA, onSubmit, disable } = props;
    // const [checkboxState, setCheckboxState] = useState({});
    // useEffect(() => {
    //     const initialState = {};
    //     band.forEach((item) => {
    //         TA.forEach((ta) => {
    //             if (ta.band === item.name) {
    //                 initialState[`band${item.name}-TA-${ta.objectId}`] = false;
    //             }
    //         });
    //         CAC.forEach((cac) => {
    //             if (cac.band === item.name) {
    //                 initialState[`band${item.name}-CAC-${cac.objectId}`] = false;
    //             }
    //         });
    //         LR.forEach((lr) => {
    //             if (lr.band === item.name) {
    //                 initialState[`band${item.name}-LR-${lr.objectId}`] = false;
    //             }
    //         });
    //         GRAA.forEach((graa) => {
    //             if (graa.band === item.name) {
    //                 initialState[`band${item.name}-GRAA-${graa.objectId}`] = false;
    //             }
    //         });
    //     });
    //     setCheckboxState(initialState);
    // }, [TA, CAC, LR, GRAA, band]);
    const handleChange = (event) => {
        const { name, checked } = event.target;
        setCheckboxState({ ...checkboxState, [name]: checked });
    };
    function scrollBottom() {
        window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: 'smooth'
        });
    }
    const handleSubmit = () => {
        let result = '';
        for (let i = 1; i <= 9; i++) {
            result += resultOptionsFeedback(i);
        }
        if (result != '') {
            scrollBottom();
            if (onSubmit) {
                onSubmit(result);
            }
        }
    };

    // const clearOptions = () => {
    //     const newState = { ...checkboxState };
    //     for (const key in newState) {
    //         newState[key] = false;
    //     }
    //     setCheckboxState(newState);
    // };

    return (
        <>
            <TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell sx={{ color: '#ffffff', opacity: '0.9' }} style={{ fontSize: '24px' }} align="left">
                                Brand
                            </TableCell>

                            <TableCell sx={{ color: '#ffffff', opacity: '0.9' }} style={{ fontSize: '24px' }} align="left">
                                Task Achievement
                            </TableCell>
                            <TableCell sx={{ color: '#ffffff', opacity: '0.9' }} style={{ fontSize: '24px' }} align="left">
                                Coherence and Cohesion
                            </TableCell>
                            <TableCell sx={{ color: '#ffffff', opacity: '0.9' }} style={{ fontSize: '24px' }} align="left">
                                Lexical Resource
                            </TableCell>
                            <TableCell sx={{ color: '#ffffff', opacity: '0.9' }} style={{ fontSize: '24px' }} align="left">
                                Grammatical Range & Accuracy
                            </TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {band.map((item) => (
                            <TableRow key={item.objectId}>
                                <TableCell align="center" sx={{ color: 'white' }}>
                                    {item.name}
                                </TableCell>
                                <TableCell className="tr-table">
                                    <Box className="td-table">
                                        {TA.map((children) =>
                                            children.band === item.name ? (
                                                <FormControlLabel
                                                    style={{ marginBottom: '10px' }}
                                                    key={children.objectId}
                                                    label={children.content}
                                                    value={children.content}
                                                    name={`band${item.name}-TA`}
                                                    control={
                                                        <Checkbox
                                                        // checked={checkboxState[`band${item.name}-TA-${children.objectId}`]}
                                                        // onChange={handleChange}
                                                        // name={`band${item.name}-TA-${children.objectId}`}
                                                        />
                                                    }
                                                />
                                            ) : (
                                                ''
                                            )
                                        )}
                                    </Box>
                                </TableCell>
                                <TableCell className="tr-table">
                                    <Box className="td-table">
                                        {CAC.map((children) =>
                                            children.band === item.name ? (
                                                <FormControlLabel
                                                    style={{ marginBottom: '10px' }}
                                                    key={children.objectId}
                                                    label={children.content}
                                                    value={children.content}
                                                    name={`band${item.name}-CAC`}
                                                    control={
                                                        <Checkbox
                                                        // checked={checkboxState[`band${item.name}-CAC-${children.objectId}`]}
                                                        // onChange={handleChange}
                                                        // name={`band${item.name}-CAC-${children.objectId}`}
                                                        />
                                                    }
                                                />
                                            ) : (
                                                ''
                                            )
                                        )}
                                    </Box>
                                </TableCell>
                                <TableCell className="tr-table">
                                    <Box className="td-table">
                                        {LR.map((children) =>
                                            children.band === item.name ? (
                                                <FormControlLabel
                                                    style={{ marginBottom: '10px' }}
                                                    key={children.objectId}
                                                    label={children.content}
                                                    value={children.content}
                                                    name={`band${item.name}-LR`}
                                                    control={
                                                        <Checkbox
                                                        // checked={checkboxState[`band${item.name}-LR-${children.objectId}`]}
                                                        // onChange={handleChange}
                                                        // name={`band${item.name}-LR-${children.objectId}`}
                                                        />
                                                    }
                                                />
                                            ) : (
                                                ''
                                            )
                                        )}
                                    </Box>
                                </TableCell>
                                <TableCell className="tr-table">
                                    <Box className="td-table" sx={{ ml: 3 }}>
                                        {GRAA.map((children) =>
                                            children.band === item.name ? (
                                                <FormControlLabel
                                                    style={{ marginBottom: '10px' }}
                                                    key={children.objectId}
                                                    label={children.content}
                                                    value={children.content}
                                                    name={`band${item.name}-GRAA`}
                                                    control={
                                                        <Checkbox
                                                        // checked={checkboxState[`band${item.name}-GRAA-${children.objectId}`]}
                                                        // onChange={handleChange}
                                                        // name={`band${item.name}-GRAA-${children.objectId}`}
                                                        />
                                                    }
                                                />
                                            ) : (
                                                ''
                                            )
                                        )}
                                    </Box>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <div className="config-btn">
                {/* <Button sx={{ background: 'red' }} variant="contained" onClick={clearOptions}>
                    Clear Options
                </Button> */}
                <div></div>
                <Button variant="contained" onClick={handleSubmit} disabled={disable}>
                    Submit
                </Button>
            </div>
        </>
    );
}

export default TableOptions;
