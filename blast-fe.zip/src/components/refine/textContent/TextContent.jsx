import React from 'react';
import PropTypes from 'prop-types';

import './TextContent.scss';

TextContent.propTypes = {
    content: PropTypes.string,
    question: PropTypes.string,
    onChangeText: PropTypes.func,
    onChangeQuestion: PropTypes.func
};

function TextContent(props) {
    const { content, question, onChangeText, onChangeQuestion } = props;

    const handleChangetext = (e) => {
        if (onChangeText) {
            onChangeText(e.target.value);
        }
    };
    const handleChangeQuestion = (e) => {
        if (onChangeQuestion) {
            onChangeQuestion(e.target.value);
        }
    };

    return (
        <>
            <div>
                <div className="title-col-band">
                    <div className="container-title-submit">
                        <span>1. Fill Your Test question</span>
                    </div>
                </div>
                <textarea
                    className="format-textarea-content mt-2"
                    value={question}
                    rows={3}
                    onChange={handleChangeQuestion}
                    placeholder="Type your sentence"
                />
            </div>
            <div>
                <div className="title-col-band">
                    <div className="container-title-submit">
                        <span>2. Your Response</span>
                        <div></div>
                    </div>
                </div>
                <textarea
                    className="format-textarea-content mt-2"
                    value={content}
                    rows={8}
                    onChange={handleChangetext}
                    placeholder="Type your sentence"
                />
            </div>
        </>
    );
}

export default TextContent;
