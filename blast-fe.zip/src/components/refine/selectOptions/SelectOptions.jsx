import React from 'react';
import PropTypes from 'prop-types';

import { Grid, Select, MenuItem, FormControl, Checkbox, FormControlLabel, Button } from '@mui/material';
import { margin } from '@mui/system';

import './SelectOptions.scss';
import { CheckBox } from '@mui/icons-material';
import { useState } from 'react';

SelectOptions.propTypes = {
    options: PropTypes.array,
    onSubmit: PropTypes.func,
    disable: PropTypes.bool
};

function SelectOptions(props) {
    const { options, onSubmit, disable } = props;

    const handleClick = (e) => {
        console.log(e.target.value);
    };
    function scrollBottom() {
        window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: 'smooth'
        });
    }
    const handleSubmit = () => {
        const result = generateListOptions();
        if (onSubmit) {
            scrollBottom();
            onSubmit(result);
        }
    };

    function generateListOptions() {
        let result = '';
        let isCheck = false;
        const listOption = document.getElementsByName('suggest');
        for (let i = 0; i < listOption.length; i++) {
            if (listOption[i].checked) {
                if (isCheck === true) {
                    result += ', ';
                }
                result += listOption[i].value;
                isCheck = true;
                // result = result === '' ? result : result ;
            }
        }
        return result;
    }
    return (
        <div>
            <div className="title-col-band">
                <div className="container-title-submit">
                    <span>3. Choose Your Options</span>
                </div>
            </div>
            <div className="select-options mt-2">
                {options.map((item) => (
                    <FormControlLabel
                        label={item.content}
                        key={item.objectId}
                        className="color-options"
                        name="suggest"
                        control={<Checkbox value={item.content} inputProps={{ 'aria-label': 'controlled' }} />}
                    />
                ))}
            </div>
            <div className="container-title-submit mt-4">
                <span></span>
                <Button className="format-button" disabled={disable} onClick={handleSubmit}>
                    Send
                </Button>
            </div>
        </div>
    );
}

export default SelectOptions;
