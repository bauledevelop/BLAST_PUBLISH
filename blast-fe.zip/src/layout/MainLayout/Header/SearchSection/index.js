const SearchSection = () => {
    return (
        <>
            <h4 style={{ padding: '20px' }}>Dashboard</h4>
        </>
    );
};

export default SearchSection;
