import bot from 'assets/images/bot/bot.svg';
import user from 'assets/images/bot/user.svg';

let loadInterval;

const loader = (element) => {
    element.textContent = '';

    loadInterval = setInterval(() => {
        // Update the text content of the loading indicator
        element.textContent += '.';

        // If the loading indicator has reached three dots, reset it
        if (element.textContent === '....') {
            element.textContent = '';
        }
    }, 300);
};

const typeText = (element, text) => {
    let index = 0;

    let interval = setInterval(() => {
        if (index < text.length) {
            element.innerHTML += text.charAt(index);
            index++;
        } else {
            clearInterval(interval);
        }
    }, 20);
};

const chatStripe = (isAi, value, uniqueId) => {
    return `
      <div class="wrapper ${isAi && 'ai'}">
      <div class="chat">
          <div class="profile">
              <img 
                src=${isAi ? bot : user} 
                alt="${isAi ? 'bot' : 'user'}" 
              />
          </div>
          <div class="message" id=${uniqueId}>${value}</div>
      </div>
  </div>
    `;
};
const generateUniqueId = () => {
    const timestamp = Date.now();
    const randomNumber = Math.random();
    const hexadecimalString = randomNumber.toString(16);

    return `id-${timestamp}-${hexadecimalString}`;
};

const clearloadingInterval = () => {
    clearInterval(loadInterval);
};

export { loader, typeText, chatStripe, generateUniqueId, clearloadingInterval };
