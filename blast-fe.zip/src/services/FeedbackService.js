const resultOptionsFeedback = (band) => {
    let stringres = `Band ${band}: `;
    let isCheck = 0;
    let col = '';
    const colOne = document.getElementsByName(`band${band}-TA`);
    const colTwo = document.getElementsByName(`band${band}-CAC`);
    const colThree = document.getElementsByName(`band${band}-LR`);
    const colFour = document.getElementsByName(`band${band}-GRAA`);

    for (var i = 0; i < colOne.length; i++) {
        console.log(colOne[i]);
        if (colOne[i].checked) {
            if (isCheck != 0) {
                col += ', ';
            }
            col += colOne[i].value;
            isCheck++;
        }
    }
    if (col != '') {
        stringres += 'Task Achievement: ' + col + '. ';
        col = '';
        isCheck = 0;
    }
    for (var i = 0; i < colTwo.length; i++) {
        if (colTwo[i].checked) {
            if (isCheck != 0) {
                col += ', ';
            }
            col += colTwo[i].value;
            isCheck++;
        }
    }
    if (col != '') {
        stringres += 'Coherence and Cohesion: ' + col + '. ';
        col = '';
        isCheck = 0;
    }
    for (var i = 0; i < colThree.length; i++) {
        if (colThree[i].checked) {
            if (isCheck != 0) {
                col += ',';
            }
            col += colThree[i].value;
            isCheck++;
        }
    }
    if (col != '') {
        stringres += 'Lexical Resource: ' + col + '. ';
        col = '';
        isCheck = 0;
    }
    for (var i = 0; i < colFour.length; i++) {
        if (colFour[i].checked) {
            if (isCheck != 0) {
                col += ', ';
            }
            col += colFour[i].value;
            isCheck++;
        }
    }
    if (col != '') {
        stringres += 'Grammatical Range & Accuracy: ' + col + '. ';
        col = '';
        isCheck = 0;
    }
    return stringres === `Band ${band}: ` ? '' : stringres;
};

const clearOptions = () => {
    var listInput = document.querySelectorAll('input');
    listInput.forEach((element) => {
        if (element.checked === true) {
            element.checked = false;
        }
    });
    // for (let i = 1; i <= 9; i++) {
    //     const colOne = document.getElementsByName(`band${i}-TA`);
    //     const colTwo = document.getElementsByName(`band${i}-CAC`);
    //     const colThree = document.getElementsByName(`band${i}-LR`);
    //     const colFour = document.getElementsByName(`band${i}-GRAA`);
    //     for (let j = 0; j < colOne.length; j++) {
    //         if (colOne[j].checked) {
    //             colOne[j].checked = false;
    //         }
    //     }
    //     // for (var j = 0; j < colTwo.length; j++) {
    //     //     colTwo[j].checked = colTwo[j].checked === true ? (colTwo[j].checked = false) : colTwo[j].checked;
    //     // }
    //     // for (var j = 0; j < colThree.length; j++) {
    //     //     colThree[j].checked = colThree[j].checked === true ? (colThree[j].checked = false) : colThree[j].checked;
    //     // }
    //     // for (var j = 0; j < colFour.length; j++) {
    //     //     colFour[j].checked = colFour[j].checked === true ? (colFour[j].checked = false) : colFour[j].checked;
    //     // }
    // }
};

export { resultOptionsFeedback, clearOptions };
