import React from 'react';
import { collection, getDocs, getDoc, addDoc, query, orderBy, doc, updateDoc, deleteDoc, where } from '@firebase/firestore';
import PropTypes from 'prop-types';
import '../../../assets/scss/all.scss';
import { lazy } from 'react';
import { useState } from 'react';
import { Checkbox, FormControlLabel } from '@mui/material';
import axios from 'axios';
import { db } from 'config/firebase.js';
import { chatStripe, clearloadingInterval, generateUniqueId, loader, typeText } from 'services/AllService';

// import { processTaskOne } from 'config/openAI';

const TextContent = lazy(() => import('components/refine/textContent/TextContent'));
const ResultData = lazy(() => import('components/resultData/ResultData'));
const SelectOptions = lazy(() => import('components/refine/selectOptions/SelectOptions'));
const dbOptions = collection(db, 'options');
Refine.propTypes = {};

function Refine() {
    const [content, setContent] = useState('');
    const [question, setQuestion] = useState('');
    const [options, setOptions] = useState([]);
    const [disable, setDisable] = useState(false);
    const chatContainer = document.querySelector('#generateChat');

    useState(() => {
        const getOptions = async () => {
            const data = await getDocs(query(dbOptions, orderBy('orderby', 'asc')));
            setOptions(data.docs.map((doc) => ({ ...doc.data(), objectId: doc.id })));
        };
        getOptions();
    }, []);
    const onChangeText = (value) => {
        setContent(value);
    };

    const onChangeQuestion = (value) => {
        setQuestion(value);
    };
    const onSubmit = async (value) => {
        setDisable(true);
        let prompt = question !== '' ? 'Question: ' + question : '';
        prompt = prompt === '' ? '' : prompt + ' ';
        prompt = content !== '' ? prompt + 'Response: ' + content : '';
        prompt = prompt === '' ? '' : prompt + '. ';
        console.log(prompt);
        chatContainer.innerHTML += chatStripe(false, prompt + 'Options: ' + value);

        const uniqueId = generateUniqueId();
        chatContainer.innerHTML += chatStripe(true, ' ', uniqueId);
        const messageDiv = document.getElementById(uniqueId);
        loader(messageDiv);
        axios
            .post('http://localhost:3001/api/tasktwo/CallAPI', {
                prompt: prompt,
                options: value
            })
            .then((res) => {
                clearloadingInterval();
                messageDiv.innerHTML = '';
                const parsedData = res.data.message.trim(); // trims any trailing spaces/'\n'
                typeText(messageDiv, parsedData);
            })
            .catch((error) => {
                console.error(error);
                clearloadingInterval();
                messageDiv.innerHTML = 'Something went wrong';
            });
        setDisable(false);
    };

    return (
        <div className="box-content-task">
            <TextContent content={content} question={question} onChangeText={onChangeText} onChangeQuestion={onChangeQuestion} />
            <SelectOptions options={options} onSubmit={onSubmit} disable={disable} />
            <ResultData />
            <hr />
        </div>
    );
}

export default Refine;
