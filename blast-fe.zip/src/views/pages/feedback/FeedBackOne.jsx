import React from 'react';
import { collection, getDocs, query, orderBy } from '@firebase/firestore';
import PropTypes from 'prop-types';
import '../../../assets/scss/all.scss';
import { lazy } from 'react';
import { useState } from 'react';
import { useEffect } from 'react';
import { db } from 'config/firebase.js';
import axios from 'axios';
import { chatStripe, clearloadingInterval, generateUniqueId, loader, typeText } from 'services/AllService';
import { useRef } from 'react';

// import { processTaskOne } from 'config/openAI';

const ResultData = lazy(() => import('components/resultData/ResultData'));
const TableOptions = lazy(() => import('components/feedback/tableOptions/TableOptions'));
const dbband = collection(db, 'band');
const dbTA = collection(db, 'TA');
const dbCAC = collection(db, 'CAC');
const dbLR = collection(db, 'LR');
const dbGRAA = collection(db, 'GRAA');

FeedBackOne.propTypes = {};

function FeedBackOne() {
    const [band, setBand] = useState([]);
    const [disable, setDisable] = useState(false);
    const [TA, setTA] = useState([]);
    const [CAC, setCAC] = useState([]);
    const [LR, setLR] = useState([]);
    const [GRAA, setGRAA] = useState([]);
    const boxResultRef = useRef(null);
    let scrollInterval;
    const chatContainer = document.querySelector('#generateChat');
    useEffect(() => {
        const getband = async () => {
            const data = await getDocs(query(dbband, orderBy('name', 'desc')));
            setBand(data.docs.map((doc) => ({ ...doc.data(), objectId: doc.id })));
        };
        const getTA = async () => {
            const data = await getDocs(query(dbTA, orderBy('orderby', 'asc')));
            setTA(data.docs.map((doc) => ({ ...doc.data(), objectId: doc.id })));
        };
        const getCAC = async () => {
            const data = await getDocs(query(dbCAC, orderBy('orderby', 'asc')));
            setCAC(data.docs.map((doc) => ({ ...doc.data(), objectId: doc.id })));
        };
        const getLR = async () => {
            const data = await getDocs(query(dbLR, orderBy('orderby', 'asc')));
            setLR(data.docs.map((doc) => ({ ...doc.data(), objectId: doc.id })));
        };
        const getGRAA = async () => {
            const data = await getDocs(query(dbGRAA, orderBy('orderby', 'asc')));
            setGRAA(data.docs.map((doc) => ({ ...doc.data(), objectId: doc.id })));
        };
        getband();
        getTA();
        getCAC();
        getLR();
        getGRAA();
    }, []);
    // function scrollBottom() {
    //     scrollInterval = setInterval(() => {
    //         boxResultRef.current.scrollTop = boxResultRef.current.scrollHeight;
    //         console.log('check');
    //     }, 0);
    // }
    const onSubmit = async (value) => {
        setDisable(true);
        chatContainer.innerHTML += chatStripe(false, value);

        const uniqueId = generateUniqueId();
        chatContainer.innerHTML += chatStripe(true, ' ', uniqueId);
        const messageDiv = document.getElementById(uniqueId);
        loader(messageDiv);
        axios
            .post('http://localhost:3001/api/taskone/CallAPI', {
                options: value
            })
            .then((res) => {
                clearloadingInterval();
                messageDiv.innerHTML = '';
                const parsedData = res.data.message.trim(); // trims any trailing spaces/'\n'
                typeText(messageDiv, parsedData);
            })
            .catch((error) => {
                console.error(error);
                clearloadingInterval();
                messageDiv.innerHTML = 'Something went wrong';
            });

        setDisable(false);
    };

    return (
        <div className="box-content-task">
            <TableOptions band={band} TA={TA} CAC={CAC} LR={LR} GRAA={GRAA} onSubmit={onSubmit} disable={disable} />
            <ResultData boxResultRef={boxResultRef} />
        </div>
    );
}

export default FeedBackOne;
